using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum CompassDirection
{
    North = 0,
    West = 90,
    South = 180,
    East = 270
}